// A very stupid predictor.  It will always predict not taken.

void init_predictor ()
{
}

bool make_prediction (unsigned int pc)
{
  return false;
}

void train_predictor (unsigned int pc, bool outcome)
{
}
