Readme
--------------------------------------------------------------------------------
Weijian Xu and Sai Wu


I. Justification for Makefile Modification
    In the codes we use 4 classes to represent 4 kind of predictors. Thus, to
make the file structure clear, we add several source files and modify the
makefile. We do not add any other options in makefile and it can be used as the
original one.

II. Command Arguments
    We use command arguments to set the parameters of predictors:
        ./predictor %trace_file_path% type={PAgA2|Perceptron|GShare|Alpha}
                    [address_length=%address_length%] [GHR_length=%GHR_length%]
                    [LHR_length=%LHR_length%] [w_length=%w_length%] [entries=%entries%]

        In which, trace_file_path: Path of trace file.
                  address_length: Count of bits of branch address we use from LSB.
                  GHR_length: Count of bits of Global History Register.
                  LHR_length: Count of bits of Local History Register.
                  w_length: Count of bits of a w parameter in Perceptron Predictor.
                  entries: Count of perceptrons in Perceptron Predictor.

        e.g. ./predictor ../traces/DIST-FP-1 type=GShare GHR_length=8 address_length=12
            Output: 8200,149820,2213673,5.078816
        e.g. ./predictor ../traces/DIST-INT-1 type=PAgA2 LHR_length=10 address_length=9
            Output: 7168,379252,4184792,12.856436
        e.g. ./predictor ../traces/DIST-SERV-1 type=Perceptron GHR_length=33 entries=30 w_length=8
            Output: 8193,542123,3660616,18.377674
        e.g. ./predictor ../traces/DIST-MM-1 type=Alpha GHR_length=10 address_length=8 LHR_length=9
            Output: 7946,288723,2229289,9.787552

    Notes 1: We disable argument theta and w_count in source files but for
             compatibility we still use these two arguments in benchmark script.
    Notes 2: When using G-Share Predictor, there is a constraint that
             address_length >= GHR_length

III. Output of Predictor Program
    For the convenience of benchmark script, we modify the original output of
predictor. Currently a sample output is:
    7946,288723,2229289,9.787552
    The first number is the actual bits we used in predictor. The second number
is the number of mis-predicted branches. The third number is the total number of
branches. The fourth number is the mis-prediction rate, which is the number of
mis-predicted branches per 1000 instructions.

IV. Python Script of Benchmark
    We write a benchmark script to generate our final results and draw a plot.
The python script benchmark.py will process 24 predictor combinations
(4 predictors * 6 budgets) in 4 traces. Finally it will draw a plot of all
results. Matplotlib support should be installed before running the script.
    Execute the following command to run the script:
        python ./benchmark.py

    Notes: Parameters tuning is not included in this benchmark script.

V. Dynamic Data Structure
    We use dynamic data structure in classes to store the tables and other
parameters within a specific budget. It is convenient to write a benchmark
script to change the parameters when using dynamic data structure in predictor.
We output the count of actual used bits to measure if it excesses budget.
